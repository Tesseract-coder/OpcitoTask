import logging

import pytest
@pytest.mark.usefixtures("Setup")
class Baseclass:

    def Getlogger(self):

        logger = logging.Logger

        return logger
