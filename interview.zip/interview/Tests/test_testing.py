import pytest
from selenium import webdriver
from selenium.webdriver.support import wait
from selenium.webdriver.common import

from Utilities.Baseclass import Baseclass
from pageobjects.Homepage import Home


class TestOne(Baseclass):

    @pytest.mark.serach

    def test_googlesearch(self):

        driver = self.driver
        objPage = Home(driver)

        driver.find_element_by_xpath(objPage.searchbox).send_keys("Cars")
        driver.find_element_by_xpath(objPage.searchbox).send_keys(keys.key.ENTER)

        driver.find_element_by_xpath(objPage.firstlink).click()

        Actualtitle= driver.title()

        assert Actualtitle == "cars - Google Search", "Title of the page is not as expected"

    def genricwait(driver, locator):
        wait = webdriver.wait(driver,30)
        wait.until(expected_condition.)







