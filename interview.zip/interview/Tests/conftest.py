from selenium import webdriver
from selenium.webdriver.support import wait
import pytest
import requests

@pytest.fixture()
def Setup(request):
    driver = webdriver.Chrome()
    driver.get("https://www.google.com/")
    driver.maximize_window()
    driver.implicitly_wait(10)
    yield request.

    driver.close()