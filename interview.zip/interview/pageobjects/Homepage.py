class Home:

    def __init__(self, driver):
        self.driver = driver

    searchbox = "//input[@name='q']"
    firstlink = "(//a//h3)[1]"